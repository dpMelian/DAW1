class Watch < ApplicationRecord
end
