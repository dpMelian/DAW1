module Api
  class WatchesController < ApplicationController
    def index 
      @watches = Watch.order('created_at DESC')
    end
  end
end
