class CreateWatches < ActiveRecord::Migration[5.2]
  def change
    create_table :watches do |t|
      t.string :name
      t.string :description
      t.string :price
      t.string :attachment

      t.timestamps
    end
  end
end
