Rails.application.routes.draw do
  resources :watches
  get 'watches/index'
  get 'watches/new'
  get 'watches/create'
  get 'watches/edit'
  get 'watches/destroy'
  # For details on the DSL available within this file, see http://guides.rubyonrails.org/routing.html

  resources :watches, only: [:index, :new, :create, :edit, :destroy]
  root "watches#index"
end

